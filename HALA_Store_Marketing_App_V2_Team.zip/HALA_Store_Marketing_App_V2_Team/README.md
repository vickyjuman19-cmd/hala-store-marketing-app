# HALA Homecare Store Marketing App V2
Team-ready field-sales foundation.

Includes:
- salesman login-ready structure
- store CRM fields
- shop photo
- GPS/map location
- products + quantities
- visit/follow-up tracking
- dashboard metrics
- CSV export
- cloud API foundation with PostgreSQL schema
- admin/team architecture

This package is an MVP foundation. Real production deployment requires hosting, database credentials, authentication provider, secure storage, and HTTPS.
