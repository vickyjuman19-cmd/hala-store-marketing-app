# Mobile App V2 Screen Specification

## Salesman
1. Login
2. Dashboard
   - Today's visits
   - New stores
   - Orders
   - Follow-ups
3. Store list
4. Add store
5. Store detail
6. Visit check-in
7. Shop camera
8. GPS/map
9. Product order
10. Follow-up
11. WhatsApp/call
12. Daily report

## Admin
1. Admin login
2. Salesmen
3. Store database
4. Map view
5. Orders
6. Product-wise sales
7. Area-wise sales
8. Follow-up pending
9. Daily/monthly reports
10. Export

## Store detail should show
Shop photo
Shop name
Owner
Phone
Area
Pincode
Exact map
Last visit
Next follow-up
Products ordered
Order quantities
Total order history
Salesman
Notes
