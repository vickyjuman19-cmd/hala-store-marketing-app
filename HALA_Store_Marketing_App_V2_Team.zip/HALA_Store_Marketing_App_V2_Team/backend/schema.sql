CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS sales_users(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 name VARCHAR(120) NOT NULL,
 phone VARCHAR(20) UNIQUE NOT NULL,
 role VARCHAR(30) NOT NULL DEFAULT 'salesman',
 active BOOLEAN DEFAULT TRUE,
 created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS stores(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 shop_name VARCHAR(180) NOT NULL,
 owner_name VARCHAR(120),
 phone VARCHAR(20),
 alt_phone VARCHAR(20),
 area VARCHAR(120),
 pincode VARCHAR(10),
 address TEXT,
 lat NUMERIC(10,7),
 lng NUMERIC(10,7),
 photo_url TEXT,
 status VARCHAR(30) DEFAULT 'prospect',
 created_by UUID REFERENCES sales_users(id),
 followup_date DATE,
 notes TEXT,
 created_at TIMESTAMPTZ DEFAULT now(),
 updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS products(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 name VARCHAR(150) UNIQUE NOT NULL,
 active BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS store_orders(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 store_id UUID REFERENCES stores(id) ON DELETE CASCADE,
 salesman_id UUID REFERENCES sales_users(id),
 order_status VARCHAR(30) DEFAULT 'pending',
 notes TEXT,
 created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS store_order_items(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 order_id UUID REFERENCES store_orders(id) ON DELETE CASCADE,
 product_id UUID REFERENCES products(id),
 quantity INT NOT NULL CHECK(quantity>0)
);

CREATE TABLE IF NOT EXISTS visits(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 store_id UUID REFERENCES stores(id) ON DELETE CASCADE,
 salesman_id UUID REFERENCES sales_users(id),
 visit_lat NUMERIC(10,7),
 visit_lng NUMERIC(10,7),
 visited_at TIMESTAMPTZ DEFAULT now(),
 notes TEXT
);

INSERT INTO products(name) VALUES
('Bathroom Cleaner'),('Floor Cleaner'),('Toilet Cleaner'),('Dish Wash'),
('Glass Cleaner'),('Detergent Liquid'),('Hand Wash'),('Room Freshener'),('Car Wash')
ON CONFLICT(name) DO NOTHING;
