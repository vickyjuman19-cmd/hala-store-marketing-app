import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import pg from 'pg';
const {Pool}=pg;
const app=express();
app.use(cors());
app.use(express.json({limit:'8mb'}));
const pool=new Pool({connectionString:process.env.DATABASE_URL});
const PORT=process.env.PORT||4000;

app.get('/health',(_,res)=>res.json({ok:true,service:'HALA Store Sales API'}));

app.get('/api/products',async(_,res)=>{
 const {rows}=await pool.query('SELECT * FROM products WHERE active=true ORDER BY name');
 res.json(rows);
});

app.get('/api/stores',async(req,res)=>{
 const {search='',status=''}=req.query;
 const {rows}=await pool.query(
  `SELECT s.*,u.name salesman_name FROM stores s
   LEFT JOIN sales_users u ON u.id=s.created_by
   WHERE ($1='' OR s.shop_name ILIKE '%'||$1||'%' OR s.owner_name ILIKE '%'||$1||'%' OR s.area ILIKE '%'||$1||'%' OR s.pincode ILIKE '%'||$1||'%')
   AND ($2='' OR s.status=$2) ORDER BY s.updated_at DESC`,[search,status]);
 res.json(rows);
});

app.post('/api/stores',async(req,res)=>{
 const {shop_name,owner_name,phone,alt_phone,area,pincode,address,lat,lng,photo_url,status='prospect',created_by,followup_date,notes}=req.body;
 if(!shop_name)return res.status(400).json({error:'shop_name required'});
 const {rows}=await pool.query(
 `INSERT INTO stores(shop_name,owner_name,phone,alt_phone,area,pincode,address,lat,lng,photo_url,status,created_by,followup_date,notes)
 VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING *`,
 [shop_name,owner_name,phone,alt_phone,area,pincode,address,lat,lng,photo_url,status,created_by,followup_date,notes]);
 res.status(201).json(rows[0]);
});

app.post('/api/visits',async(req,res)=>{
 const {store_id,salesman_id,visit_lat,visit_lng,notes}=req.body;
 const {rows}=await pool.query(
 `INSERT INTO visits(store_id,salesman_id,visit_lat,visit_lng,notes) VALUES($1,$2,$3,$4,$5) RETURNING *`,
 [store_id,salesman_id,visit_lat,visit_lng,notes]);
 res.status(201).json(rows[0]);
});

app.post('/api/orders',async(req,res)=>{
 const {store_id,salesman_id,items=[],notes}=req.body;
 if(!store_id||!items.length)return res.status(400).json({error:'store_id and items required'});
 const c=await pool.connect();
 try{
  await c.query('BEGIN');
  const o=await c.query(
   `INSERT INTO store_orders(store_id,salesman_id,notes) VALUES($1,$2,$3) RETURNING *`,
   [store_id,salesman_id,notes]);
  for(const x of items) await c.query(
   `INSERT INTO store_order_items(order_id,product_id,quantity) VALUES($1,$2,$3)`,
   [o.rows[0].id,x.product_id,x.quantity]);
  await c.query(`UPDATE stores SET status='trial',updated_at=now() WHERE id=$1`,[store_id]);
  await c.query('COMMIT');
  res.status(201).json(o.rows[0]);
 }catch(e){await c.query('ROLLBACK');res.status(500).json({error:e.message})}
 finally{c.release()}
});

app.get('/api/dashboard',async(_,res)=>{
 const [s,o,v]=await Promise.all([
  pool.query('SELECT COUNT(*)::int count FROM stores'),
  pool.query('SELECT COUNT(*)::int count FROM store_orders'),
  pool.query(`SELECT COUNT(*)::int count FROM visits WHERE visited_at::date=CURRENT_DATE`)
 ]);
 res.json({stores:s.rows[0].count,orders:o.rows[0].count,todayVisits:v.rows[0].count});
});

app.listen(PORT,()=>console.log(`HALA Store Sales API on ${PORT}`));
